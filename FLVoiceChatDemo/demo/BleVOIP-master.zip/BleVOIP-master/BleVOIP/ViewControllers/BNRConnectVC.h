//
//  BNRPeripheralTVC.h
//  BleChatRoom
//
//  Created by JustinYang on 11/29/15.
//  Copyright © 2015 JustinYang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BNRConnectVC : UITableViewController

@property (nonatomic)       RoleType    roleType;
@end
