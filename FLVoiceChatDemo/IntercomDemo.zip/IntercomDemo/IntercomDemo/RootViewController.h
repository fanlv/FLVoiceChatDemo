//
//  RootViewController.h
//  IntercomDemo
//
//  Created by MacOS on 14-9-27.
//  Copyright (c) 2014年 MacOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>

#import "RecordAmrCode.h"
#import "GCDAsyncUdpSocket.h"

/**
 *  缓存区的个数，一般3个
 */
#define kNumberAudioQueueBuffers 3

#define kNumberAudioQueueBuffers1 100
/**
 *  采样率，要转码为amr的话必须为8000
 */
#define kDefaultSampleRate 8000

#define kDefaultInputBufferSize 7360

#define kDefaultOutputBufferSize 7040

#define kDefaultIP @"192.168.1.18"

#define kDefaultPort  8080

NSMutableArray *receiveData;//接收数据的数组

@interface RootViewController : UIViewController
{
    AudioQueueRef                   _inputQueue;
    AudioQueueRef                   _outputQueue;
    AudioStreamBasicDescription     _audioFormat;
    
    AudioQueueBufferRef     _inputBuffers[kNumberAudioQueueBuffers];
    AudioQueueBufferRef     _outputBuffers[kNumberAudioQueueBuffers];
}

@property (weak, nonatomic) IBOutlet UIButton *startButton;
@property (weak, nonatomic) IBOutlet UIButton *stopButton;

@property (strong, nonatomic) GCDAsyncUdpSocket             *udpSocket;

@property (assign, nonatomic) AudioQueueRef                 inputQueue;
@property (assign, nonatomic) AudioQueueRef                 outputQueue;
@property (strong, nonatomic) RecordAmrCode                 *recordAmrCode;

- (IBAction)startIntercom:(id)sender;
- (IBAction)stopIntercom:(id)sender;
@end
