//
//  RootViewController.m
//  IntercomDemo
//
//  Created by MacOS on 14-9-27.
//  Copyright (c) 2014年 MacOS. All rights reserved.
//

#import "RootViewController.h"

@interface RootViewController ()

@end

@implementation RootViewController

#pragma mark 生命周期方法
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //socket
    GCDAsyncUdpSocket *udpSocket = [[GCDAsyncUdpSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_main_queue()];
    self.udpSocket = udpSocket;
    //绑定端口
	[self.udpSocket bindToPort:kDefaultPort error:nil];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 私有方法
// 设置录音格式
- (void)setupAudioFormat:(UInt32) inFormatID SampleRate:(int)sampeleRate
{
    //重置下
    memset(&_audioFormat, 0, sizeof(_audioFormat));
    
    //设置采样率，这里先获取系统默认的测试下 //TODO:
    //采样率的意思是每秒需要采集的帧数
    _audioFormat.mSampleRate = sampeleRate;//[[AVAudioSession sharedInstance] sampleRate];
    
    //设置通道数,这里先使用系统的测试下 //TODO:
    _audioFormat.mChannelsPerFrame = 1;//(UInt32)[[AVAudioSession sharedInstance] inputNumberOfChannels];
    
    //设置format，怎么称呼不知道。
    _audioFormat.mFormatID = inFormatID;
    
    if (inFormatID == kAudioFormatLinearPCM){
        //这个屌属性不知道干啥的。，
        _audioFormat.mFormatFlags = kLinearPCMFormatFlagIsSignedInteger | kLinearPCMFormatFlagIsPacked;
        //每个通道里，一帧采集的bit数目
        _audioFormat.mBitsPerChannel = 16;
        //结果分析: 8bit为1byte，即为1个通道里1帧需要采集2byte数据，再*通道数，即为所有通道采集的byte数目。
        //所以这里结果赋值给每帧需要采集的byte数目，然后这里的packet也等于一帧的数据。
        //至于为什么要这样。。。不知道。。。
        _audioFormat.mBytesPerPacket = _audioFormat.mBytesPerFrame = (_audioFormat.mBitsPerChannel / 8) * _audioFormat.mChannelsPerFrame;
        _audioFormat.mFramesPerPacket = 1;
    }
}

//初始化会话
- (void)initSession
{
    UInt32 sessionCategory = kAudioSessionCategory_MediaPlayback;         //可在后台播放声音
    AudioSessionSetProperty(kAudioSessionProperty_AudioCategory, sizeof(sessionCategory), &sessionCategory);
    
    UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;  //设置成话筒模式
    AudioSessionSetProperty (kAudioSessionProperty_OverrideAudioRoute,
                             sizeof (audioRouteOverride),
                             &audioRouteOverride);
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    //默认情况下扬声器播放
    [audioSession setCategory:AVAudioSessionCategoryPlayback error:nil];
    [audioSession setActive:YES error:nil];
}

//录音回调
void GenericInputCallback (
                           void                                *inUserData,
                           AudioQueueRef                       inAQ,
                           AudioQueueBufferRef                 inBuffer,
                           const AudioTimeStamp                *inStartTime,
                           UInt32                              inNumberPackets,
                           const AudioStreamPacketDescription  *inPacketDescs
                           )
{
    NSLog(@"录音回调方法");
    RootViewController *rootCtrl = (__bridge RootViewController *)(inUserData);
    
    if (inNumberPackets > 0) {
        NSData *pcmData = [[NSData alloc] initWithBytes:inBuffer->mAudioData length:inBuffer->mAudioDataByteSize];
        //pcm数据不为空时，编码为amr格式
        if (pcmData && pcmData.length > 0) {
            NSData *amrData = [rootCtrl.recordAmrCode encodePCMDataToAMRData:pcmData];
            
            [rootCtrl.udpSocket sendData:amrData toHost:kDefaultIP port:kDefaultPort withTimeout:-1 tag:0];
            
            
        }
        
    }
    AudioQueueEnqueueBuffer (inAQ,inBuffer,0,NULL);
    
}

// 输出回调
void GenericOutputCallback (
                            void                 *inUserData,
                            AudioQueueRef        inAQ,
                            AudioQueueBufferRef  inBuffer
                            )
{
    NSLog(@"播放回调");
    RootViewController *rootCtrl = (__bridge RootViewController *)(inUserData);
    NSData *pcmData = nil;
    if([receiveData count] >0)
    {
        NSData *amrData = [receiveData objectAtIndex:0];
        
        pcmData = [rootCtrl.recordAmrCode decodeAMRDataToPCMData:amrData];
        
        if (pcmData) {
            if(pcmData.length < 10000){
                memcpy(inBuffer->mAudioData, pcmData.bytes, pcmData.length);
                inBuffer->mAudioDataByteSize = (UInt32)pcmData.length;
                inBuffer->mPacketDescriptionCount = 0;
            }
        }
        [receiveData removeObjectAtIndex:0];
    }
    else
    {
        makeSilent(inBuffer);
    }
    AudioQueueEnqueueBuffer(rootCtrl.outputQueue,inBuffer,0,NULL);
}


//开始对讲
- (IBAction)startIntercom:(id)sender {
    //让udpSocket 开始接收数据
    [self.udpSocket beginReceiving:nil];
    //先把接收数组清空
    if (receiveData) {
        receiveData = nil;
    }
    receiveData = [[NSMutableArray alloc] init];
    
    if (_recordAmrCode == nil) {
        _recordAmrCode = [[RecordAmrCode alloc] init];
    }
    //设置录音的参数
    [self setupAudioFormat:kAudioFormatLinearPCM SampleRate:kDefaultSampleRate];
    _audioFormat.mSampleRate = kDefaultSampleRate;
    //创建一个录制音频队列
    AudioQueueNewInput (&(_audioFormat),GenericInputCallback,(__bridge void *)self,NULL,NULL,0,&_inputQueue);
    //创建一个输出队列
    AudioQueueNewOutput(&_audioFormat, GenericOutputCallback, (__bridge void *) self, CFRunLoopGetCurrent(), kCFRunLoopDefaultMode, 0,&_outputQueue);
    //设置话筒属性等
    [self initSession];
    
    NSError *error = nil;
    //设置audioSession格式 录音播放模式
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:&error];
    
    UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;  //设置成话筒模式
    AudioSessionSetProperty (kAudioSessionProperty_OverrideAudioRoute,
                             sizeof (audioRouteOverride),
                             &audioRouteOverride);
    
    //创建录制音频队列缓冲区
    for (int i = 0; i < kNumberAudioQueueBuffers; i++) {
        AudioQueueAllocateBuffer (_inputQueue,kDefaultInputBufferSize,&_inputBuffers[i]);
        
        AudioQueueEnqueueBuffer (_inputQueue,(_inputBuffers[i]),0,NULL);
    }
    
    //创建并分配缓冲区空间 4个缓冲区
    for (int i = 0; i<kNumberAudioQueueBuffers; ++i)
    {
        AudioQueueAllocateBuffer(_outputQueue, kDefaultOutputBufferSize, &_outputBuffers[i]);
    }
    for (int i=0; i < kNumberAudioQueueBuffers; ++i) {
        makeSilent(_outputBuffers[i]);  //改变数据
        // 给输出队列完成配置
        AudioQueueEnqueueBuffer(_outputQueue,_outputBuffers[i],0,NULL);
    }
    
    Float32 gain = 1.0;                                       // 1
    // Optionally, allow user to override gain setting here 设置音量
    AudioQueueSetParameter (_outputQueue,kAudioQueueParam_Volume,gain);
    
    //开启录制队列
    AudioQueueStart(self.inputQueue, NULL);
    //开启播放队列
    AudioQueueStart(_outputQueue,NULL);
    
    [_startButton setEnabled:NO];
    [_stopButton setEnabled:YES];
    
}

//把缓冲区置空
void makeSilent(AudioQueueBufferRef buffer)
{
    for (int i=0; i < buffer->mAudioDataBytesCapacity; i++) {
        buffer->mAudioDataByteSize = buffer->mAudioDataBytesCapacity;
        UInt8 * samples = (UInt8 *) buffer->mAudioData;
        samples[i]=0;
    }
}

//结束对讲
- (IBAction)stopIntercom:(id)sender {
    //暂停接收数据
    [self.udpSocket pauseReceiving];
    
    AudioQueueDispose(_inputQueue, YES);
    AudioQueueDispose(_outputQueue, YES);
    
    [_startButton setEnabled:YES];
    [_stopButton setEnabled:NO];
    
}

#pragma mark - GCDAsyncUdpSocketDelegate
- (void)udpSocket:(GCDAsyncUdpSocket *)sock didReceiveData:(NSData *)data
      fromAddress:(NSData *)address
withFilterContext:(id)filterContext
{
    //这里因为对录制的PCM数据编码为amr格式并添加RTP包头之后的大小，大家可以根据自己的协议，在包头中封装上数据长度再来解析。
    //PS：因为socket在发送过程中会粘包，如发送数据AAA,然后再发送BBB,可能会一次收到AAABBB，也可能会一次收到AAA，另一次收到BBB，所以针对这种情况要判断接收数据大小，来拆包
    if(data.length >667)
    {
        int num = (data.length)/667;
        int sum = 0;
        for (int i=0; i<num; i++)
        {
            NSData *receviceData = [data subdataWithRange:NSMakeRange(i*667,667)];
            [receiveData addObject:receviceData];
            sum = sum+667;
        }
        if(sum < data.length)
        {
            NSData *otherData = [data subdataWithRange:NSMakeRange(sum, (data.length-sum))];
            [receiveData addObject:otherData];
        }
    }
    else
    {
        [receiveData addObject:data];
    }
    
}


@end
